# WAZAP — Série recrutement livreurs (TikTok @wazap_ci + Statuts WhatsApp)

Numéro à publier : **0104320317** (déjà intégré dans chaque visuel/vidéo). Appel à l'action commun : écrire **« DEVENIR LIVREUR »** sur WhatsApp.

Même gabarit visuel que la série de lancement WAZAP (blanc/beige, liseré or, vert WAZAP), avec une offre différente mise en avant : **1 smartphone offert** (programme Ambassadeur WAZAP : compte certifié + 250 livraisons + 5 filleuls actifs), au lieu des "15 commandes offertes" côté commerçants — pour ne pas mélanger les deux publics.

| Jour | Fichier | Format | Thème |
|---|---|---|---|
| 1 | `jour01_video.mp4` | Vidéo (19,5s) | Hook — "Tu as une moto ? Des courses près de chez toi, chaque jour." |
| 2 | `jour02_visuel.png` | Visuel | Guide — "Devenir livreur, en 3 étapes" |
| 3 | `jour03_video.mp4` | Vidéo (19,5s) | L'offre — 250 livraisons + 5 filleuls = 1 smartphone (programme Ambassadeur WAZAP) |
| 4 | `jour04_visuel.png` | Visuel | FAQ — "Faut-il un diplôme pour devenir livreur ?" |
| 5 | `jour05_video.mp4` | Vidéo (19,5s) | Parrainage — chaque filleul rapproche du smartphone offert |
| 6 | `jour06_visuel.png` | Visuel | Appel final — "Chaque jour, des commerces cherchent un livreur près de chez toi" |

## Comment publier

**TikTok (@wazap_ci)** : programmer les jours vidéo (1, 3, 5) via TikTok Studio, un par jour, comme pour la série de lancement. Dis-moi quand tu veux que je m'en occupe.

**Statuts WhatsApp (0104320317)** : Statut → Ajouter un statut → choisis le fichier du jour → poste tel quel, aucun texte à ajouter.

## Pourquoi ce contenu, et pas autre chose

- Aucune promesse inventée : les 3 conditions de l'offre smartphone (compte certifié, 250 livraisons, 5 filleuls) et le principe "zéro frais" viennent directement du programme "Ambassadeur WAZAP" déjà actif dans le produit — rien n'est exagéré.
- Le canal WhatsApp de recrutement est actuellement **manuel** (le bot automatique est en pause le temps d'un déblocage technique côté Meta) : chaque candidat qui écrit doit être traité à la main pour l'instant — prévoir quelqu'un qui suit les messages entrants sur `0104320317` pendant la diffusion.
- Prochaine étape naturelle : les messages types pour la prospection B2B (sociétés de livraison, coursiers, taxi-motos) à partir de la liste `ProspectCollector` — je peux les rédiger dès que tu veux.
